YOUR SWITCH MUST BE HACKED VIA SOFTWARE/HARDWARE TO USE THIS MOD!!!

This mod is specifically for Super Mario Odyssey v1.0.0 and has only been tested on it.
Expect bugs/crashes on other versions of the game.

How to install:
Copy the atmosphere folder to the root of your Switch's SD card.